﻿<Serializable>
Public Class Database
    Public Pastas As New List(Of Folder)
    Public Atalhos As New List(Of Atalhos)
    Public Senhaadmin As String = "admin"
End Class

