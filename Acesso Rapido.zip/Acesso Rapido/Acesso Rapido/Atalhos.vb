﻿<Serializable>
Public Class Atalhos
    Public Nome As String = ""
    Public Patch As String = ""
    Public Isfolder As Boolean = False
    Public isFolderPR As Boolean = False
    Public Adicionadoem As String = ""
    Public Pasta As String = ""
    Public Acessadoem As String = ""
    Public Extensao As String = ""
End Class
